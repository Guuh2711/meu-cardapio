# Meu Cardápio Personalizado
Este projeto gera cardápios personalizados com integração Stripe e Flask.
