// Script JS básico
console.log('Olá mundo!');
