# Função de geração de PDF (exemplo)
def gerar_pdf(dados):
    pass
